exports.id = 557;
exports.ids = [557];
exports.modules = {

/***/ 4033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_logo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6207);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5893);







const Navbar = () => {
  const {
    0: isMenuOpen,
    1: setIsMenuOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: isScrolled,
    1: setIsScrolled
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      setIsScrolled(scrollTop > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("nav", {
    className: `text-black fixed top-0 left-0 right-0 z-50 ${isScrolled ? 'bg-white' : 'bg-transparent'}`,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: "flex items-center justify-between p-4",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "flex items-center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
          href: "/",
          legacyBehavior: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
            className: "flex items-center space-x-2",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
              src: _public_logo_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
              alt: "Logo",
              className: "h-12 w-12"
            })
          })
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: "relative md:hidden",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("button", {
          className: `text-gray-400 hover:text-white focus:outline-none focus:text-white ${isScrolled ? 'text-white' : 'text-gray-400'}`,
          onClick: toggleMenu,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("svg", {
            className: "h-6 w-6 fill-current",
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            children: isMenuOpen ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M19 13H5v-2h14v2zM19 7H5V5h14v2z"
            }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M4 6h16v2H4V6zm0 5h16v2H4v-2zm0 5h16v2H4v-2z"
            })
          })
        }), isMenuOpen && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
          className: "absolute top-full right-0 mt-2 w-48 bg-gray-500  shadow-lg rounded-md",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
            href: "/casestudy",
            legacyBehavior: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Case Studies"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
            href: "/services",
            legacyBehavior: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Services"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
            href: "/about",
            legacyBehavior: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "About Us"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
            href: "/contact",
            legacyBehavior: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Contact Us"
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
            href: "/about",
            legacyBehavior: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Blog"
            })
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: "hidden md:flex  space-x-16 mr-40 ",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
          href: "/casestudy",
          legacyBehavior: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
            className: "hover:text-gray-300",
            children: "Case Studies"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
          href: "/services",
          legacyBehavior: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
            className: "hover:text-gray-300",
            children: "Services"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
          href: "/about",
          legacyBehavior: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
            className: "hover:text-gray-300",
            children: "About Us"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
          href: "/contact",
          legacyBehavior: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
            className: "hover:text-gray-300",
            children: "Contact Us"
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
          href: "/about",
          legacyBehavior: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
            className: "hover:text-gray-300",
            children: "Blog"
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

/***/ }),

/***/ 8557:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/Footer.js





const Footer = () => {
  return /*#__PURE__*/jsx_runtime.jsx("footer", {
    className: "bg-gray-800 text-white",
    children: /*#__PURE__*/jsx_runtime.jsx("div", {
      className: "container mx-auto py-8 px-4 md:px-8",
      children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "grid grid-cols-1 md:grid-cols-4 pt-8",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "p-4 flex flex-col items-center md:gap-2 md:items-start",
          children: [/*#__PURE__*/jsx_runtime.jsx("div", {
            className: "px-3 md:h-[190px] py-3 mb-4",
            children: /*#__PURE__*/jsx_runtime.jsx("p", {
              className: "mb-4 text-start md:mr-8 text-[14px] w-[228px]",
              children: "Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequeat,vel illum dolore eu feuguat nulla"
            })
          }), /*#__PURE__*/jsx_runtime.jsx("img", {
            src: "/logo.png",
            alt: "Logo",
            className: "ml-4 mt-4 md:mt-0",
            width: 100,
            height: 100
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "p-4",
          children: [/*#__PURE__*/jsx_runtime.jsx("h2", {
            className: "font-bold text-start mb-4 text-[28px]",
            children: "Talk to us"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "w-[304px] h-[77px] text-[14px] text-start",
            children: [/*#__PURE__*/jsx_runtime.jsx("p", {
              className: "text-start mb-2",
              children: "Phone: +971 4 4548684"
            }), /*#__PURE__*/jsx_runtime.jsx("p", {
              className: "text-start",
              children: "Email: talk2u@flc-me.com"
            })]
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "md:mt-16 mt-4",
            children: [/*#__PURE__*/jsx_runtime.jsx("h2", {
              className: "font-bold text-start mb-4 text-[28px]",
              children: "Follow Us"
            }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
              className: "flex",
              children: [/*#__PURE__*/jsx_runtime.jsx("a", {
                href: "https://www.linkedin.com/",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "mr-4",
                children: /*#__PURE__*/jsx_runtime.jsx(fa_.FaLinkedin, {
                  size: 24
                })
              }), /*#__PURE__*/jsx_runtime.jsx("a", {
                href: "https://www.facebook.com/",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "mr-4",
                children: /*#__PURE__*/jsx_runtime.jsx(fa_.FaFacebook, {
                  size: 24
                })
              }), /*#__PURE__*/jsx_runtime.jsx("a", {
                href: "https://www.instagram.com/",
                target: "_blank",
                rel: "noopener noreferrer",
                className: "mr-4",
                children: /*#__PURE__*/jsx_runtime.jsx(fa_.FaInstagram, {
                  size: 24
                })
              }), /*#__PURE__*/jsx_runtime.jsx("a", {
                href: "https://www.whatsapp.com/",
                target: "_blank",
                rel: "noopener noreferrer",
                children: /*#__PURE__*/jsx_runtime.jsx(fa_.FaWhatsapp, {
                  size: 24
                })
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "p-4",
          children: [/*#__PURE__*/jsx_runtime.jsx("h2", {
            className: "font-bold text-start md:text-start mb-4 text-[28px]",
            children: "Visit Us"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "text-start md:text-start flex flex-col gap-6 text-[14px] w-[304px]",
            children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
              className: "mb-2",
              children: [/*#__PURE__*/jsx_runtime.jsx("strong", {
                children: "UAE Office:"
              }), " 1501, Concord Tower, Media City, PO Box 283795, Dubai, UAE."]
            }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
              className: "mb-2",
              children: [/*#__PURE__*/jsx_runtime.jsx("strong", {
                children: "India Office:"
              }), " 401 B, Unitech Arcadia, South City 2, Sec 49, Gurugram - 122018 India."]
            }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
              children: [/*#__PURE__*/jsx_runtime.jsx("strong", {
                children: "KSA Office:"
              }), " Al Tadamun Al Arabi Street, Mishrifah Dist, Jeddah SA."]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "p-4 md:ml-9",
          children: [/*#__PURE__*/jsx_runtime.jsx("h2", {
            className: "font-bold text-start md:text-start mb-4 text-[28px]",
            children: "Quick Links"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "text-start md:text-start",
            children: [/*#__PURE__*/jsx_runtime.jsx("a", {
              href: "/link1",
              className: "block mt-2",
              children: /*#__PURE__*/jsx_runtime.jsx("p", {
                className: "text-white hover:text-gray-300 transition duration-300",
                children: "About Us"
              })
            }), /*#__PURE__*/jsx_runtime.jsx("a", {
              href: "/link2",
              className: "block mt-2",
              children: /*#__PURE__*/jsx_runtime.jsx("p", {
                className: "text-white hover:text-gray-300 transition duration-300",
                children: "Service"
              })
            }), /*#__PURE__*/jsx_runtime.jsx("a", {
              href: "/joinOurTeam",
              className: "block mt-2",
              children: /*#__PURE__*/jsx_runtime.jsx("p", {
                className: "text-white hover:text-gray-300 transition duration-300",
                children: "JOin our Team"
              })
            })]
          }), /*#__PURE__*/jsx_runtime.jsx("p", {
            className: "mt-8 md:pr-20 md:ml-[-150px]  text-center md:mt-44",
            children: "\xA9 2023 FLC Group all Rights Reserved."
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const components_Footer = (Footer);
// EXTERNAL MODULE: ./src/components/Navbar.js
var Navbar = __webpack_require__(4033);
// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
;// CONCATENATED MODULE: ./src/pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "flex flex-col min-h-screen",
    children: [/*#__PURE__*/jsx_runtime.jsx(Component, _objectSpread({}, pageProps)), /*#__PURE__*/jsx_runtime.jsx(components_Footer, {})]
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 6207:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.73e580b2.png","height":979,"width":1000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/0lEQVR42mMAg5gN1pWBc4+8U5O5+tZB/dZbM/Wz70LUlBhAICFihUBy2JL9d1T9bn6NZ5j4pUdjydfJSke+NKvs/dqsLMygHr5yYb/v5LP/gWoZoODPV4Gon2eknn8pUl3LYBe69Epc+NI9DECwqzSUcemcB0wg9ueXkht/HJE5xWDqt3BZYMCiC9PLNvIzQIH0Pgb5VWfs9/9/x7qCwb1pf6xd5oYbplYzZzuwxsmaT/2vGbhxdv2Rq2IP/7+SqmOI2vJMKXT57VU+fSeu+U6/dDJx9dmzFftybly5xTjt/0dVdQYQqOthYPJd9Sa8bOeSJX0nGHZPPMkQBrMOAKdIbWPegQ/TAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 108:
/***/ (() => {



/***/ })

};
;