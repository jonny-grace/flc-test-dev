exports.id = 139;
exports.ids = [139];
exports.modules = {

/***/ 8720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_Blog)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/Ellipse.png
/* harmony default export */ const Ellipse = ({"src":"/_next/static/media/Ellipse.24339df5.png","height":105,"width":105,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAR0lEQVR42m2NwQ3AMAgDvQ7f6/4P2CcDhE9qNeqjVXRCGBC2JIKiTRJ6xnGtDYMQaTFZZlqVaLd9d9GHRX1e8mf65iRtipBugr4+bed/VsEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/Blog.js






const Blog = () => {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    class: "max-w-[85rem]  px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto md:mx-10 mb-10 bg-gray-300",
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      class: "max-w-2xl mx-auto text-left ml-10 mb-10 lg:mb-14",
      children: [/*#__PURE__*/jsx_runtime.jsx("p", {
        class: "mt-1 text-black text-2xl mb-4 ",
        children: "from our blog"
      }), /*#__PURE__*/jsx_runtime.jsx("h2", {
        class: "text-2xl font-bold md:text-6xl md:leading-tight text-black",
        children: "We are curiosity-driven"
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      class: "grid sm:grid-cols-2 lg:grid-cols-4 gap-6 md:grid-cols-2 ml-10 md:ml-1",
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("a", {
        class: "group hover:bg-gray-100 rounded-xl p-5 transition-all dark:hover:bg-white/[.05]",
        href: "#",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          class: "mt-auto items-center gap-x-6",
          children: [/*#__PURE__*/jsx_runtime.jsx((image_default()), {
            class: "w-20 h-20 rounded-full",
            src: Ellipse,
            alt: "Image Description"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "mt-6 flex items-center justify-start  w-64",
            children: [/*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-2",
              children: "by Nidhi"
            }), /*#__PURE__*/jsx_runtime.jsx("div", {
              className: "border-r border-gray-400 h-4 mr-2"
            }), /*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-4",
              children: "  Strategy & Growth"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime.jsx("h3", {
          class: "mt-5 text-xl text-black font-bold",
          children: "gen z shopper experience"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          class: "mt-3 inline-flex items-center gap-x-2 text-sm font-semibold text-black",
          children: ["Read more", /*#__PURE__*/jsx_runtime.jsx("svg", {
            class: "w-2.5 h-2.5 transition ease-in-out group-hover:translate-x-1",
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/jsx_runtime.jsx("path", {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M0.975821 6.92249C0.43689 6.92249 -3.50468e-07 7.34222 -3.27835e-07 7.85999C-3.05203e-07 8.37775 0.43689 8.79749 0.975821 8.79749L12.7694 8.79748L7.60447 13.7596C7.22339 14.1257 7.22339 14.7193 7.60447 15.0854C7.98555 15.4515 8.60341 15.4515 8.98449 15.0854L15.6427 8.68862C16.1191 8.23098 16.1191 7.48899 15.6427 7.03134L8.98449 0.634573C8.60341 0.268455 7.98555 0.268456 7.60447 0.634573C7.22339 1.00069 7.22339 1.59428 7.60447 1.9604L12.7694 6.92248L0.975821 6.92249Z",
              fill: "currentColor"
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("a", {
        class: "group hover:bg-gray-100 rounded-xl p-5 transition-all dark:hover:bg-white/[.05]",
        href: "#",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          class: "mt-auto items-center gap-x-5",
          children: [/*#__PURE__*/jsx_runtime.jsx((image_default()), {
            class: "w-20 h-20 rounded-full",
            src: Ellipse,
            alt: "Image Description"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "mt-6 flex items-center justify-start  w-64",
            children: [/*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-2",
              children: "by Nidhi"
            }), /*#__PURE__*/jsx_runtime.jsx("div", {
              className: "border-r border-gray-400 h-4 mr-2"
            }), /*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-4",
              children: "  Strategy & Growth"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime.jsx("h3", {
          class: "mt-5 text-xltext-black font-bold",
          children: "gen z shopper experience"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          class: "mt-3 inline-flex items-center gap-x-2 text-sm font-semibold text-black",
          children: ["Read more", /*#__PURE__*/jsx_runtime.jsx("svg", {
            class: "w-2.5 h-2.5 transition ease-in-out group-hover:translate-x-1",
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/jsx_runtime.jsx("path", {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M0.975821 6.92249C0.43689 6.92249 -3.50468e-07 7.34222 -3.27835e-07 7.85999C-3.05203e-07 8.37775 0.43689 8.79749 0.975821 8.79749L12.7694 8.79748L7.60447 13.7596C7.22339 14.1257 7.22339 14.7193 7.60447 15.0854C7.98555 15.4515 8.60341 15.4515 8.98449 15.0854L15.6427 8.68862C16.1191 8.23098 16.1191 7.48899 15.6427 7.03134L8.98449 0.634573C8.60341 0.268455 7.98555 0.268456 7.60447 0.634573C7.22339 1.00069 7.22339 1.59428 7.60447 1.9604L12.7694 6.92248L0.975821 6.92249Z",
              fill: "currentColor"
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("a", {
        class: "group hover:bg-gray-100 rounded-xl p-5 transition-all dark:hover:bg-white/[.05]",
        href: "#",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          class: "mt-auto items-center gap-x-5",
          children: [/*#__PURE__*/jsx_runtime.jsx((image_default()), {
            class: "w-20 h-20 rounded-full",
            src: Ellipse,
            alt: "Image Description"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "mt-6 flex items-center justify-start  w-64",
            children: [/*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-2",
              children: "by Nidhi"
            }), /*#__PURE__*/jsx_runtime.jsx("div", {
              className: "border-r border-gray-400 h-4 mr-2"
            }), /*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-4",
              children: "  Strategy & Growth"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime.jsx("h3", {
          class: "mt-5 text-xl text-black font-bold",
          children: "gen z shopper experience"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          class: "mt-3 inline-flex items-center gap-x-2 text-sm font-semibold text-black",
          children: ["Read more", /*#__PURE__*/jsx_runtime.jsx("svg", {
            class: "w-2.5 h-2.5 transition ease-in-out group-hover:translate-x-1",
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/jsx_runtime.jsx("path", {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M0.975821 6.92249C0.43689 6.92249 -3.50468e-07 7.34222 -3.27835e-07 7.85999C-3.05203e-07 8.37775 0.43689 8.79749 0.975821 8.79749L12.7694 8.79748L7.60447 13.7596C7.22339 14.1257 7.22339 14.7193 7.60447 15.0854C7.98555 15.4515 8.60341 15.4515 8.98449 15.0854L15.6427 8.68862C16.1191 8.23098 16.1191 7.48899 15.6427 7.03134L8.98449 0.634573C8.60341 0.268455 7.98555 0.268456 7.60447 0.634573C7.22339 1.00069 7.22339 1.59428 7.60447 1.9604L12.7694 6.92248L0.975821 6.92249Z",
              fill: "currentColor"
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("a", {
        class: "group hover:bg-gray-100 rounded-xl p-5 transition-all dark:hover:bg-white/[.05]",
        href: "#",
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          class: "mt-auto items-center gap-x-5",
          children: [/*#__PURE__*/jsx_runtime.jsx((image_default()), {
            class: "w-20 h-20 rounded-full",
            src: Ellipse,
            alt: "Image Description"
          }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "mt-6 flex items-center justify-start  w-64",
            children: [/*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-2",
              children: "by Nidhi"
            }), /*#__PURE__*/jsx_runtime.jsx("div", {
              className: "border-r border-gray-400 h-4 mr-2"
            }), /*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mr-4",
              children: "  Strategy & Growth"
            })]
          })]
        }), /*#__PURE__*/jsx_runtime.jsx("h3", {
          class: "mt-5 text-xl text-black font-bold",
          children: "gen z shopper experience"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          class: "mt-3 inline-flex items-center gap-x-2 text-sm font-semibold text-black",
          children: ["Read more", /*#__PURE__*/jsx_runtime.jsx("svg", {
            class: "w-2.5 h-2.5 transition ease-in-out group-hover:translate-x-1",
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/jsx_runtime.jsx("path", {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M0.975821 6.92249C0.43689 6.92249 -3.50468e-07 7.34222 -3.27835e-07 7.85999C-3.05203e-07 8.37775 0.43689 8.79749 0.975821 8.79749L12.7694 8.79748L7.60447 13.7596C7.22339 14.1257 7.22339 14.7193 7.60447 15.0854C7.98555 15.4515 8.60341 15.4515 8.98449 15.0854L15.6427 8.68862C16.1191 8.23098 16.1191 7.48899 15.6427 7.03134L8.98449 0.634573C8.60341 0.268455 7.98555 0.268456 7.60447 0.634573C7.22339 1.00069 7.22339 1.59428 7.60447 1.9604L12.7694 6.92248L0.975821 6.92249Z",
              fill: "currentColor"
            })
          })]
        })]
      })]
    })]
  });
};

/* harmony default export */ const components_Blog = (Blog);

/***/ }),

/***/ 6539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_Client)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/company.jpg
/* harmony default export */ const company = ({"src":"/_next/static/media/company.233c5ae8.jpg","height":129,"width":163,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAq4P/xAAaEAEAAgMBAAAAAAAAAAAAAAACAQMABFER/9oACAEBAAE/ADUa9t7AbiHHiHZ7n//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/Client.js






const Client = () => {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "container mx-auto mt-5",
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "w-11/12 xl:w-2/3 lg:w-2/3 md:w-2/3 mx-auto sm:mb-10 mb-16",
      children: [/*#__PURE__*/jsx_runtime.jsx("h1", {
        className: "xl:text-5xl md:text-3xl text-xl text-center text-gray-800 font-extrabold mb-5 pt-4",
        children: "Clients"
      }), /*#__PURE__*/jsx_runtime.jsx("p", {
        className: "text-base md:text-lg lg:text-xl text-center text-gray-600 font-normal xl:w-12/12 xl:mx-auto",
        children: "Our diverse clientele fuels our passion for crafting standout campaigns. Join our league of clients and let's create marketing wonders together!"
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "xl:py-16 lg:py-16 md:py-16 sm:py-16 px-15",
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "flex flex-wrap justify-center gap-2 md:gap-10",
        children: [/*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 70,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "flex flex-wrap justify-center gap-2 md:gap-10 my-10",
        children: [/*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        }), /*#__PURE__*/jsx_runtime.jsx((image_default()), {
          src: company,
          alt: "Company Logo",
          width: 75,
          height: 75
        })]
      })]
    })]
  });
};

/* harmony default export */ const components_Client = (Client);

/***/ }),

/***/ 685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ Gallery)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-tabs"
var external_react_tabs_ = __webpack_require__(5973);
// EXTERNAL MODULE: ./node_modules/react-tabs/style/react-tabs.css
var react_tabs = __webpack_require__(8096);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./public/assets/bg.jpg
/* harmony default export */ const bg = ({"src":"/_next/static/media/bg.549bc2d5.jpg","height":831,"width":1280,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAwT/2gAMAwEAAhADEAAAAIIUj//EABoQAAICAwAAAAAAAAAAAAAAAAECAAMEEjH/2gAIAQEAAT8AK470kJSVYP3ctP/EABcRAAMBAAAAAAAAAAAAAAAAAAABAhH/2gAIAQIBAT8ApZTP/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAECEf/aAAgBAwEBPwCXso//2Q==","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/IntegratedTabContent.js




const BoxComponent = () => {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: " mt-5  flex md:flex-row md:w-[1200px] md:h-[650px] flex-col",
    children: [/*#__PURE__*/jsx_runtime.jsx("div", {
      className: "flex-grow md:w-[300px]",
      children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "relative flex h-full",
        children: [/*#__PURE__*/jsx_runtime.jsx("img", {
          src: "/assets/DPOufH.png",
          alt: "Your Image",
          className: "object-cover hover:cursor-pointer w-full"
        }), /*#__PURE__*/jsx_runtime.jsx("div", {
          className: "absolute inset-0 flex  bg-gray-500 bg-opacity-50 text-white p-4",
          children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            children: [/*#__PURE__*/jsx_runtime.jsx("p", {
              className: "text-xl font-semibold text-left",
              children: "featured // events"
            }), /*#__PURE__*/jsx_runtime.jsx("h2", {
              className: "text-4xl font-bold mt-10",
              children: "Honor Magic Pro Launch"
            }), /*#__PURE__*/jsx_runtime.jsx("p", {
              className: "mt-3 font-semibold",
              children: "Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla"
            }), /*#__PURE__*/jsx_runtime.jsx("span", {
              className: "mt-2 inline-flex items-center gap-x-1.5 text-sm text-white decoration-2 group-hover:underline font-medium",
              children: "Learn more"
            })]
          })
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex-grow flex flex-col",
      children: [/*#__PURE__*/jsx_runtime.jsx("div", {
        className: "flex-grow",
        children: /*#__PURE__*/jsx_runtime.jsx("img", {
          src: "bulk-image2.jpeg",
          alt: "Image for Column b2",
          className: "object-cover hover:cursor-pointer w-full h-full"
        })
      }), /*#__PURE__*/jsx_runtime.jsx("div", {
        className: "flex-grow pt-80 bg-green-400 hover:cursor-pointer",
        children: /*#__PURE__*/jsx_runtime.jsx("h2", {
          className: "text-4xl font-bold mt-[-300px] w-48 px-10",
          children: "Undiz Influencers"
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex-grow flex flex-col",
      children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "flex-grow pt-72 bg-purple-400 hover:cursor-pointer",
        children: [/*#__PURE__*/jsx_runtime.jsx("h2", {
          className: "text-4xl font-bold mt-[-280px] w-48 px-10",
          children: "Ajmal Perfumes"
        }), /*#__PURE__*/jsx_runtime.jsx("p", {
          className: " w-96 px-10",
          children: "you can modify the code to display all the tabs horizontally instead of wrapping them."
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("a", {
          children: [/*#__PURE__*/jsx_runtime.jsx("span", {
            className: " w-96 px-10 mt-20 ",
            children: "Learn More"
          }), " "]
        })]
      }), /*#__PURE__*/jsx_runtime.jsx("div", {
        className: "flex-grow",
        children: /*#__PURE__*/jsx_runtime.jsx("img", {
          src: "bulk-image2.jpeg",
          alt: "Image for Column C2",
          className: "object-cover hover:cursor-pointer w-full h-full"
        })
      })]
    })]
  });
};

/* harmony default export */ const IntegratedTabContent = (BoxComponent);
;// CONCATENATED MODULE: ./src/components/tabfiletest.js




const tabfiletest_BoxComponent = () => {
  return /*#__PURE__*/_jsxs("div", {
    className: "container mt-5 bg-orange-300 flex md:flex-row md:w-[1200px] md:h-[650px] flex-col",
    children: [/*#__PURE__*/_jsx("div", {
      className: "flex-grow bg-red-400 md:w-[300px]",
      children: /*#__PURE__*/_jsxs("div", {
        className: "relative flex h-full",
        children: [/*#__PURE__*/_jsx("img", {
          src: "bulk-image.jpeg",
          alt: "Your Image",
          className: "object-cover w-full"
        }), /*#__PURE__*/_jsxs("div", {
          className: "absolute top-0 left-0 p-4",
          children: [/*#__PURE__*/_jsx("h2", {
            className: "text-white text-2xl font-bold",
            children: "Image Title"
          }), /*#__PURE__*/_jsx("p", {
            className: "text-white text-lg",
            children: "Short Description"
          })]
        })]
      })
    }), /*#__PURE__*/_jsxs("div", {
      className: "flex-grow flex flex-col",
      children: [/*#__PURE__*/_jsx("div", {
        className: "flex-grow bg-blue-400",
        children: /*#__PURE__*/_jsx("img", {
          src: "bulk-image2.jpeg",
          alt: "Image for Column B1",
          className: "object-cover w-full"
        })
      }), /*#__PURE__*/_jsx("div", {
        className: "flex-grow pt-80 bg-green-400",
        children: "column b2"
      })]
    }), /*#__PURE__*/_jsxs("div", {
      className: "flex-grow flex flex-col",
      children: [/*#__PURE__*/_jsx("div", {
        className: "flex-grow pt-72 bg-purple-400",
        children: "column c1"
      }), /*#__PURE__*/_jsx("div", {
        className: "flex-grow bg-gray-400",
        children: /*#__PURE__*/_jsx("img", {
          src: "bulk-image2.jpeg",
          alt: "Image for Column C2",
          className: "object-cover w-full h-full"
        })
      })]
    })]
  });
};

/* harmony default export */ const tabfiletest = ((/* unused pure expression or super */ null && (tabfiletest_BoxComponent)));
;// CONCATENATED MODULE: ./src/components/Gallery.js











const GaleryTab = () => {
  const {
    0: activeTab,
    1: setActiveTab
  } = (0,external_react_.useState)(0);

  const handleTabClick = index => {
    setActiveTab(index);
  };

  return /*#__PURE__*/jsx_runtime.jsx("div", {
    className: " flex flex-col items-center",
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)(external_react_tabs_.Tabs, {
      selectedIndex: activeTab,
      onSelect: handleTabClick,
      children: [/*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.TabList, {
        className: "flex justify-center flex-wrap",
        children: ['Integrated', 'FMCG', 'Electronics', 'Fashion & Lifestyle', 'Food & Beverage'].map((tab, index) => /*#__PURE__*/(0,jsx_runtime.jsxs)((external_react_default()).Fragment, {
          children: [index > 0 && /*#__PURE__*/jsx_runtime.jsx("div", {
            className: "border-l mx-2 h-6 hidden md:block"
          }), " ", /*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.Tab, {
            children: tab
          })]
        }, tab))
      }), /*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.TabPanel, {
        children: /*#__PURE__*/jsx_runtime.jsx("div", {
          className: "min-h-screen md:min-h-0",
          children: /*#__PURE__*/jsx_runtime.jsx(IntegratedTabContent, {})
        })
      }), /*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.TabPanel, {
        children: /*#__PURE__*/jsx_runtime.jsx("div", {
          className: "min-h-screen md:min-h-0",
          children: /*#__PURE__*/jsx_runtime.jsx(IntegratedTabContent, {})
        })
      }), /*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.TabPanel, {
        children: /*#__PURE__*/jsx_runtime.jsx("div", {
          className: "min-h-screen md:min-h-0",
          children: /*#__PURE__*/jsx_runtime.jsx(IntegratedTabContent, {})
        })
      }), /*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.TabPanel, {
        children: /*#__PURE__*/jsx_runtime.jsx("div", {
          className: "min-h-screen md:min-h-0",
          children: /*#__PURE__*/jsx_runtime.jsx(IntegratedTabContent, {})
        })
      }), /*#__PURE__*/jsx_runtime.jsx(external_react_tabs_.TabPanel, {
        children: /*#__PURE__*/jsx_runtime.jsx("div", {
          className: "min-h-screen md:min-h-0",
          children: /*#__PURE__*/jsx_runtime.jsx(IntegratedTabContent, {})
        })
      })]
    })
  });
};

/* harmony default export */ const Gallery = (GaleryTab);

/***/ }),

/***/ 3261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5893);




const Hero = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("section", {
    className: "relative w-full bg-cover bg-center bg-no-repeat",
    style: {
      backgroundImage: "url(/assets/homeimage.png)"
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: "absolute inset-0 bg-black opacity-50"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: "relative mx-auto max-w-screen-xl px-4 py-32 sm:px-6 lg:flex lg:justify-center lg:h-screen lg:items-center lg:px-8",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "max-w-xl text-center sm:text-left text-white",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h1", {
          className: "text-5xl lg:text-7xl md:pl-10 font-extrabold",
          children: "beyond"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("strong", {
          className: "block font-extrabold text-5xl lg:text-7xl",
          children: "experiance"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "mt-8  flex flex-wrap justify-center sm:text-center lg:text-left",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            href: "#",
            className: "block w-full sm:w-auto rounded bg-white px-12 py-3 text-sm font-medium text-rose-600 shadow hover:text-rose-700 focus:outline-none focus:ring active:text-rose-500",
            children: "Learn More"
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);

/***/ }),

/***/ 5474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5893);




const Service = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: "max-w-[85rem] px-4 py-10 sm:px-6 lg:px-16 lg:py-14 mx-auto",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "font-bold justify-center items-center text-center ",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h1", {
        className: "text-5xl lg:text-7xl md:pl-10 font-extrabold",
        children: "beyond"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("strong", {
        className: "block font-extrabold md:pl-10 text-5xl lg:text-7xl",
        children: "Marketing"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("p", {
        className: "mt-10 font-semibold text-1xl   md:text-center text-start",
        children: ["Join us, as we navigate the uncharted waters of experiential marketing. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("br", {}), "At FLC, we are the dreamers, the explorers and the architects crafting immersive ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("br", {}), "moments that captivate hearts and minds"]
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 items-center justify-center gap-2 mt-10 ",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("a", {
        className: "group flex flex-col justify-center items-center  hover:bg-gray-50 rounded-xl p-4 md:p-7 dark:hover:bg-slate-800",
        href: "#",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "flex  w-24 h-24",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
            src: "/assets/marketing1.png",
            alt: "Your Image",
            className: "object-cover w-full"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
          className: "mt-5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
            className: "text-lg font-semibold text-red-600",
            children: "Marketing"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
            className: "mt-1 text-gray-800",
            children: "Engaging audiences through success driven marketing campaigns"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
            className: "mt-2 inline-flex items-center gap-x-1.5 text-sm text-blue-600 decoration-2 group-hover:underline font-medium",
            children: "Learn more"
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("a", {
        className: "group flex flex-col justify-center items-center hover:bg-gray-50 rounded-xl p-4 md:p-7 dark:hover:bg-slate-800",
        href: "#",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "flex  w-24 h-24",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
            src: "/assets/events.png",
            alt: "Your Image",
            className: "object-cover w-full"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
          className: "mt-5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
            className: "group-hover:text-gray-600 text-lg font-semibold text-red-600",
            children: "Events & Exhibition"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
            className: "mt-1 text-gray-800 ",
            children: "Curating exceptional brand experiences through dynamic events"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
            className: "mt-2 inline-flex items-center gap-x-1.5 text-sm text-blue-600 decoration-2 group-hover:underline font-medium",
            children: "Learn more"
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("a", {
        className: "group flex flex-col justify-center items-center hover:bg-gray-50 rounded-xl p-4 md:p-7 dark:hover:bg-slate-800",
        href: "#",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "flex  w-24 h-24",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
            src: "/assets/digital.png",
            alt: "Your Image",
            className: "object-cover w-full"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
          className: "mt-5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
            className: "group-hover:text-gray-600 text-lg font-semibold text-blue-600",
            children: "Digital"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
            className: "mt-1 text-gray-800",
            children: "Strategically orchestrating impactful and result oriented digital campaigns"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
            className: "mt-2 inline-flex items-center gap-x-1.5 text-sm text-blue-600 decoration-2 group-hover:underline font-medium",
            children: "Learn more"
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("a", {
        className: "group flex flex-col justify-center items-center hover:bg-gray-50 rounded-xl p-4 md:p-7 dark:hover:bg-slate-800",
        href: "#",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "flex  w-24 h-24",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
            src: "/assets/contentproduction.png",
            alt: "Your Image",
            className: "object-cover w-full"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
          className: "mt-5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
            className: "group-hover:text-gray-600 text-lg font-semibold text-blue-600",
            children: "Content Productio"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
            className: "mt-1 text-gray-800 ",
            children: "Crafting content that brings your brand ' s story to life"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
            className: "mt-2 inline-flex items-center gap-x-1.5 text-sm text-blue-600 decoration-2 group-hover:underline font-medium",
            children: "Learn more"
          })]
        })]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Service);

/***/ }),

/***/ 4139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomePage)
});

// EXTERNAL MODULE: ./src/components/Blog.js + 1 modules
var Blog = __webpack_require__(8720);
// EXTERNAL MODULE: ./src/components/Client.js + 1 modules
var Client = __webpack_require__(6539);
// EXTERNAL MODULE: ./src/components/Gallery.js + 3 modules
var Gallery = __webpack_require__(685);
// EXTERNAL MODULE: ./src/components/Hero.js
var Hero = __webpack_require__(3261);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./public/logo.png
var logo = __webpack_require__(6207);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/HomePageNavbar.js







const HomePageNavBar = () => {
  const {
    0: isMenuOpen,
    1: setIsMenuOpen
  } = (0,external_react_.useState)(false);
  const {
    0: isScrolled,
    1: setIsScrolled
  } = (0,external_react_.useState)(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  (0,external_react_.useEffect)(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      setIsScrolled(scrollTop > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  return /*#__PURE__*/jsx_runtime.jsx("nav", {
    className: ` fixed top-0 left-0 right-0 z-50 ${isScrolled ? 'bg-gray-100 text-black' : 'bg-transparent text-white'}`,
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "flex items-center justify-between p-4",
      children: [/*#__PURE__*/jsx_runtime.jsx("div", {
        className: "flex items-center",
        children: /*#__PURE__*/jsx_runtime.jsx((link_default()), {
          href: "/",
          legacyBehavior: true,
          children: /*#__PURE__*/jsx_runtime.jsx("a", {
            className: "flex items-center space-x-2",
            children: /*#__PURE__*/jsx_runtime.jsx((image_default()), {
              src: logo/* default */.Z,
              alt: "Logo",
              className: "h-12 w-12"
            })
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "relative md:hidden",
        children: [/*#__PURE__*/jsx_runtime.jsx("button", {
          className: `text-gray-400 hover:text-white focus:outline-none focus:text-white ${isScrolled ? 'text-white' : 'text-gray-400'}`,
          onClick: toggleMenu,
          children: /*#__PURE__*/jsx_runtime.jsx("svg", {
            className: "h-6 w-6 fill-current",
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            children: isMenuOpen ? /*#__PURE__*/jsx_runtime.jsx("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M19 13H5v-2h14v2zM19 7H5V5h14v2z"
            }) : /*#__PURE__*/jsx_runtime.jsx("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M4 6h16v2H4V6zm0 5h16v2H4v-2zm0 5h16v2H4v-2z"
            })
          })
        }), isMenuOpen && /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
          className: "absolute top-full right-0 mt-2 w-48 bg-gray-500  shadow-lg rounded-md",
          children: [/*#__PURE__*/jsx_runtime.jsx((link_default()), {
            href: "/casestudy",
            legacyBehavior: true,
            children: /*#__PURE__*/jsx_runtime.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Case Studies"
            })
          }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
            href: "/services",
            legacyBehavior: true,
            children: /*#__PURE__*/jsx_runtime.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Services"
            })
          }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
            href: "/about",
            legacyBehavior: true,
            children: /*#__PURE__*/jsx_runtime.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "About Us"
            })
          }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
            href: "/contact",
            legacyBehavior: true,
            children: /*#__PURE__*/jsx_runtime.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Contact Us"
            })
          }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
            href: "/about",
            legacyBehavior: true,
            children: /*#__PURE__*/jsx_runtime.jsx("a", {
              className: "block py-1 hover:text-gray-300",
              children: "Blog"
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "hidden md:flex  space-x-16 mr-40 ",
        children: [/*#__PURE__*/jsx_runtime.jsx((link_default()), {
          href: "/casestudy",
          legacyBehavior: true,
          children: /*#__PURE__*/jsx_runtime.jsx("a", {
            className: "hover:text-gray-300",
            children: "Case Studies"
          })
        }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
          href: "/services",
          legacyBehavior: true,
          children: /*#__PURE__*/jsx_runtime.jsx("a", {
            className: "hover:text-gray-300",
            children: "Services"
          })
        }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
          href: "/about",
          legacyBehavior: true,
          children: /*#__PURE__*/jsx_runtime.jsx("a", {
            className: "hover:text-gray-300",
            children: "About Us"
          })
        }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
          href: "/contact",
          legacyBehavior: true,
          children: /*#__PURE__*/jsx_runtime.jsx("a", {
            className: "hover:text-gray-300",
            children: "Contact Us"
          })
        }), /*#__PURE__*/jsx_runtime.jsx((link_default()), {
          href: "/about",
          legacyBehavior: true,
          children: /*#__PURE__*/jsx_runtime.jsx("a", {
            className: "hover:text-gray-300",
            children: "Blog"
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const HomePageNavbar = (HomePageNavBar);
// EXTERNAL MODULE: ./src/components/Service.js
var Service = __webpack_require__(5474);
;// CONCATENATED MODULE: ./src/pages/Home.js





 // import Footer from "../components/Footer";



function HomePage() {
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
    className: "w-full overflow-x-hidden",
    children: [/*#__PURE__*/jsx_runtime.jsx(HomePageNavbar, {}), /*#__PURE__*/jsx_runtime.jsx(Hero/* default */.Z, {}), /*#__PURE__*/jsx_runtime.jsx(Service/* default */.Z, {}), /*#__PURE__*/jsx_runtime.jsx(Gallery/* default */.Z, {}), /*#__PURE__*/jsx_runtime.jsx(Client/* default */.Z, {}), /*#__PURE__*/jsx_runtime.jsx(Blog/* default */.Z, {})]
  });
}

/***/ }),

/***/ 8096:
/***/ (() => {



/***/ })

};
;