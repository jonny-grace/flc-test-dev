import Blog from "../components/Blog";
import Client from "../components/Client";
import Gallery from "../components/Gallery";
import Hero from "../components/Hero";
import Service from "../components/Service";
import HomePage from "./Home";

// import Footer from "../components/Footer";


export default function Home() {
  return (
   
    <HomePage />
    
  
  )
}
